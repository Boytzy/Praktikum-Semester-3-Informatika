package Tugas;

public class Driver{
    public static void main(String[] args) {
        Balok balok = new Balok();
        balok.setPanjang(10);
        balok.setLebar(10);
        balok.setTinggi(10);
        balok.hasil();
    }
}
